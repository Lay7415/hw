import React from 'react';
import "./Items.css"
import Count from './Count'

function Items () {
    return <div className="Items">
        <Count/>
    </div>
}
export default Items